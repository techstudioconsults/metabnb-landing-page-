export { default as Logo } from './Group-1.png';
export { default as HeroImage } from './Group 4028.png';
